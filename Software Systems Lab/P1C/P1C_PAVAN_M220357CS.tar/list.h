#include "queue.h"

void insert(char[], char[], struct course *[], int);
void delete (char[], char[], struct course *[], int);
void inorderTreeWalk(struct courseRegisterList *);
void printRegList(char[], struct course *[], int);
void inorderTreeWalkWithStack(struct courseRegisterList *);
